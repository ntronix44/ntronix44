/*
                   ARDUINO MPPT BASED ON THE BUCK CONVERTER TOPOLOGY
                   -500W max
                   -updates will be built basing on this topology
                   -P & O MPPT ALGORITHM WITH CCCV 
*/
#include <Arduino.h>
#include <SPI.h>
#include <Wire.h>
#include <avr/wdt.h> 
#include <Adafruit_ADS1X15.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27,16,2);           ////SYSTEM PARAMETER - Configure LCD RowCol Size and I2C Address
Adafruit_ADS1115 ads;                      /////SYSTEM PARAMETER - ADS1115 ADC Library.

///////////////////////////////////////////////////INITIALISING PINS/////////////////////////////////////////////////////////////////////
const byte 
vIN_PIN =                                           0, ////Input pv voltage sensor
vOUT_PIN =                                          3, ////output voltage sensor
cIN_PIN =                                           2, /////input current sensor
TempSensor =                                        A3,
Buzzer =                                            PC0,
ADC_ALERT =                                         PD6,
FAN =                                               PD4,
DC_BUTTON =                                         PD2,
INVERTER_BUTTON =                                   PD7,
PWR_EN =                                            PB0,
PWR_DISABLE =                                       PB4,
DC_OUTPUT =                                         PD3,
AC_OUTPUT =                                         PD5,
PWM_OUT1 =                                          PB1,  ///OCR1A
BUCK_EN =                                           PB2,  ///OCR1B
BACKFLOW_CONTROL =                                  PB3,
LED_STATUS =                                        PB5; ///active when charging

////////////////////////////////////////////////MPPT VARIABLES////////////////////////////////////////////////////////////////////////////
float 
PPWM =                                              0.0000,
DUTYCYCLE =                                         0.0000,
vIN =                                               0.0000, // input voltage
cIN =                                               0.0000, // input current
cOUT =                                              0.0000,
vOUT =                                              0.0000, // output voltage
PREV_vIN =                                          0.0000, //previous input voltage(aids in P&O MPPT method)
PREV_POWER =                                        0.0000, //previous input power
pIN =                                               0.0000, //input power(current value) P'= pIN- PREV_POW.
PWR_IN_THRES =                                      0.50500, 
powerOut =                                          0.0000,
cIN_MAX =                                           20.0000, // maximum output current
cOUT_MAX =                                          35.00000,
cOUT_Charge =                                       30.00000,
VOC =                                               18.30000, // Panel open circuit voltage
vOUT_MAX =                                          0.00,  // maximum output voltage
vIN_MAX =                                           50.00000, //maximum input voltage
vOUT_MIN =                                          0.000,     //MIN battery voltage ie 0%
currentSens =                                       0.0660,   // sensitivity for the ACS712 -30A 
currentMidPoint =                                   2.47250,   // can be adjusted for accuracy
voltageBatteryThresh =                              0.700,
voltageDrop =                                       0.5000,
VSI =                                               0.00000,
VSO =                                               0.00000,
CSI =                                               0.00000, 
TS =                                                0.00000,
TSlog =                                             0.0000,
ADC_BitReso =                                       0.0000,
floatTemp =                                         0.0000,
RAW_cIN  =                                          0.0000,
min_dutycycle =                                     0.23,
max_dutycycle =                                     0.99,
ntcresistance   =                                   10000.00,
inputDivRatio =                                     21.00000,
outputDivRatio =                                    24.664000;    // Divider Ratio= (R1+R2)/R1

#define MPPT_MATH                                  (0.99*(vOUT_MAX / vIN))

unsigned long 
POWER_ZERO_COUNT =                                   0,
last_count_time =                                    0,
currentMillis,
previousMillis =                                     0,
currentErrorMillis =                                 0,
currentRoutineMillis =                               0,
prevErrorMillis =                                    0,
lastUpdateTime =                                     0,
lastDebounce1 =                                      0,
lastDebounce2 =                                      0,
LastSensorTime =                                     0,
lastscroll =                                         0,
lastAnimateTime =                                    0,
lastMPPTtime =                                       0,
lAST_PWR_EN_TIME =                                   0, 
lastBuzzerTime =                                     0,
lastRetry =                                          0,
buttonPressTime =                                    0;      

const unsigned long
count_time =                                         600,
POWER_ZERO_MAX_COUNT =                               1000,
Event_timer =                                        3600000,
RetryTime =                                          300000,
onduration1    =                                     1000,
onduration2    =                                     200,
offduration1   =                                     1000,
errorTimeLimit =                                     200,
offduration2   =                                     200,
debounceDelay =                                      500,
LcdUpdateTime =                                      500,
SensorTime =                                         850,
ScrollTime =                                         750,
AnimateTime =                                        150,
MPPTUpdate =                                         200,
IDLE_TIME_LIMIT =                                    120000,
Power_on_time =                                      1500;

////////////////////////////////////////////// LOGIC BOOLEANS ///////////////////////////////////////////////////////////////////////////

bool 
buck_Enable =                                         0,
Charging_pause =                                      0,
DETECT_BATT =                                         1,
PST =                                                 1, // INITIAL POWER STATE
Vsc =                                                 0,
SOT =                                                 0, // System Temperature
bypassEN =                                            0, // Backflow Control boolean
FAN_STATUS =                                          0, // Detection for input source boolean
PV_ON =                                               0, // booleans making decisions on the the status indi 
LOAD =                                                0, // 
STATUS =                                              1, //
OOV =                                                 0,
BTL =                                                 0, //Battery low
OTE =                                                 0, //OUTPUT ENABLE
IOV =                                                 0,
IOC =                                                 0,
REC =                                                 0, //Recovery boolean from faults
LOD_ON =                                              0;

int
buttonState1 =                                        1,
buttonState2 =                                        1,
lastbuttoState1 =                                     1,
lastbuttonState2  =                                   1,
ACstate =                                             0,
DCstate =                                             0,
tempFan =                                             45,
tempMax =                                             90,
sampleStoreTS =                                       0,
ADC_GainSelect =                                      1,
avgCountTS =                                          400,
avgCountVS =                                          3,
avgCountCS  =                                         5,
icr =                                                 512,
ERR =                                                 0,
inputValue =                                          0,
outputValue=                                          0,
errorCount =                                          0,
errorCountLimit =                                     3,
currentValue =                                        0,
temperature   =                                       0,
batteryPercent =                                      0,
lcdCol =                                              16,
ScrollIndex =                                         0;       

byte
Sol_char[8] =  {B11111,B10101, B11111,B10101,B11111, B10101,B10101, B11111},
Temp_char[8] = {B00100, B01010, B00100, B00000, B00000, B00000, B00000, B00000},
Bat_char[8] = {B01110, B11111, B10001, B10001, B11111, B11111, B11111, B11111},
BOLT[8]     = {B01010,B01010, B11111, B11111, B00100, B00100,B00100, B00100 },
LOD [8]   = {B00100, B01010, B10001, B11111, B11111, B11111, B11111, B11111};

String message = " NTRONIX  uniqueness with green energy. Save the environment and money with green energy.";
////////////////////////////////////////////////////// MPPT FUNCTIONS////////////////////////////////////////////////////////////////////

void ADC_SetGain(){
if(ADC_GainSelect==0){ads.setGain(GAIN_TWOTHIRDS);ADC_BitReso= 0.1875;} // Gain: 2/3x Range: +/- 6.144V
else if(ADC_GainSelect==1){ads.setGain(GAIN_ONE);ADC_BitReso= 0.125;} // Gain: 1x Range: +/- 4.096V
else if(ADC_GainSelect==2){ads.setGain(GAIN_TWO);ADC_BitReso= 0.0625;} // Gain: 2x Range: +/- 2.048V
}

void Read_Sensors(){
 if( millis() -LastSensorTime > SensorTime){
    LastSensorTime = millis();
 
if(sampleStoreTS<=avgCountTS){ //TEMPERATURE SENSOR - Lite Averaging
TS = TS + analogRead(TempSensor);
sampleStoreTS++;
}
else{
TS = TS/sampleStoreTS;
TSlog = log(ntcresistance*(1023.00/TS-1.00));
temperature = (1.0/(1.009249522e-03+2.378405444e-04*TSlog+2.019202697e-07*TSlog*TSlog*TSlog))-273.15;
sampleStoreTS = 0;
TS = 0;
}

/////////// VOLTAGE & CURRENT SENSORS /////////////
VSI = 0.0000; //Clear Previous Input Voltage
VSO = 0.0000; //Clear Previous Output Voltage
CSI = 0.0000; //Clear Previous Input Current

//VOLTAGE SENSOR - Instantenous Averaging
for(int i = 0; i<avgCountVS; i++){
VSI = VSI + ads.computeVolts(ads.readADC_SingleEnded(vIN_PIN));
VSO = VSO + ads.computeVolts(ads.readADC_SingleEnded(vOUT_PIN));
}
vIN = (VSI/avgCountVS)*inputDivRatio;
vOUT = (VSO/ avgCountVS) *outputDivRatio;
if( vIN < 0.000)  vIN = 0.000;
else if ( vOUT < 0.0000) vOUT = 0.000;
if(DETECT_BATT == 1){
  DETECT_BATT = 0;
  lcd.setCursor(0,0);
  lcd.print("Detect battery");
  delay(1000);
  lcd.clear();
if(vOUT>= 14.35 && vOUT<= 16.8) {vOUT_MIN = 12.87; vOUT_MAX = 16.4; lcd.setCursor(0,0); lcd.print("Battery is a"); lcd.setCursor(0,1); lcd.print(" 14.8V SYSTEM"); delay(2000); lcd.clear();}

else if(vOUT>= 22.00 && vOUT<= 30.00) {vOUT_MIN = 22.00; vOUT_MAX = 29.8; lcd.setCursor(0,0); lcd.print(" Battery is a"); lcd.setCursor(0,1); lcd.print(" 24V SYSTEM"); delay(2000); lcd.clear();}

else {vOUT_MIN = 10.5; vOUT_MAX = 14.7; lcd.setCursor(0,0); lcd.print(" Battery is a"); lcd.setCursor(0,1); lcd.print("  12V SYSTEM"); delay(2000); lcd.clear();}
 }

//CURRENT SENSOR - Instantenous Averaging

for(int i = 0; i<avgCountCS; i++){
CSI = CSI + ads.computeVolts(ads.readADC_SingleEnded(cIN_PIN));
}
RAW_cIN = ((CSI/avgCountCS)-0.03);
cIN = ((RAW_cIN - currentMidPoint))/ currentSens;
if(cIN < 0.000) {cIN = 0.0000;}

pIN = vIN*cIN; //calculation of power input , in future versions power output will have to be considered
powerOut = 0.98*pIN;    
if(vOUT <= 0){ cOUT = 0.000;}
else{ cOUT = ((vIN*cIN)*0.98)/vOUT;}
//delay(3);
batteryPercent = ((vOUT - vOUT_MIN)/(vOUT_MAX-vOUT_MIN))* 101;
batteryPercent = constrain(batteryPercent, 0, 100);

if(bypassEN==0 && IOV ==0 && OOV ==0){currentMidPoint =((CSI/avgCountCS)-0.03);}  // Automatic Sensor Callibration
/*
Serial.print("powerInput");
Serial.println(pIN);
Serial.print("inputV");
Serial.println(inputValue);
Serial.print("outputV");
Serial.println(outputValue);
Serial.print("RAW_CIN ====");
Serial.println(RAW_cIN);
Serial.print("CurrentMidPoint ==");
Serial.println(currentMidPoint);
Serial.print("currentV");
Serial.println(currentValue);
Serial.print("cOUT =");
Serial.println(cOUT);
Serial.print("VIN=");
Serial.println(vIN);
Serial.print("VOUT=");
Serial.println(vOUT);
Serial.print("cIN=");
Serial.println(cIN);
Serial.print("temperature");
Serial.println(temperature);
Serial.print("batteryPercent=");
Serial.println(batteryPercent);//*/
} 
}
void MPPT_Enable(){
  buck_Enable  = 1;
currentMillis = millis();
 if ((currentMillis -previousMillis) > (STATUS == 1 ? onduration2 : offduration2))
 {
    previousMillis = currentMillis;
    STATUS =! STATUS;
    PORTB^= (1<< LED_STATUS);
 }
 PORTB |= (1<< BUCK_EN);
}

void mppt_Disable(){
  buck_Enable = 0;
currentMillis = millis();
 if ((currentMillis - previousMillis)> (STATUS == 1 ? onduration1 : offduration1))
 {
    previousMillis = currentMillis;
    STATUS =! STATUS;
 PORTB^= (1<< LED_STATUS);
 }
 PORTB &= ~(1<< BUCK_EN);
 OCR1A = 0;
}
//----------------------------------------------------------DEVICE PROTECTION            ---------------------------------------------------------//
void beepBuzzer(int beepCount) {
  for (int i = 0; i < beepCount; i++) {
    PORTC |= (1<< Buzzer);
    delay(200);  // Buzzer on for 200ms
    PORTC &= ~(1 << Buzzer);
    delay(100);  // Buzzer off for 200ms
  }
}
void Device_Protection(){

if(millis()-prevErrorMillis>=errorTimeLimit){      //Run routine every millisErrorInterval (ms)
prevErrorMillis = millis();                        //Store previous time
if(errorCount < errorCountLimit){errorCount=0;}
else{}                                                   // TO ADD: sleep and charging pause if too  many errors persist
}
                   //DETECTING FAULTS
 ERR = 0;                                                     //Reset local error counter
 if(cIN > cIN_MAX) { IOC=1;ERR++;errorCount++; beepBuzzer(2); } else{IOC=0;}                              //IOC - INPUT OVERCURRENT: Input current has reached absolute limit
 if (vOUT > vOUT_MAX+voltageBatteryThresh ){ REC =1; OOV=1;ERR++;errorCount++; beepBuzzer(4); }else{OOV=0;}       //OOV- OUTPUT OVERVOLTAGE: Output voltage
 if( vIN < (vOUT + voltageDrop) || vIN > vIN_MAX) { IOV = 1; ERR++ ; errorCount++; REC= 1;} else{IOV = 0;} // IOV = INPUT OVERVOLTAGE  AND OVER VOLTAGE BOOLEAN AND RECOVERY TRIGGER.
if(temperature >= tempMax) { SOT = 1; ERR ++; errorCount++; beepBuzzer(3);} else{ SOT = 0; }           // SYSTEM OVERTEMPERATURE
if (temperature < tempFan) { FAN_STATUS = 0; PORTD &= ~(1<< FAN);}
if (temperature >= tempFan) { FAN_STATUS = 1; PORTD |= (1<< FAN);}

vIN >= VOC? Vsc = 1 : Vsc = 0;                                          // VOLTAGE INPUT AT PANEL OPEN CIRCUIT VOLTAGE.

PV_ON = (vIN > (vOUT + voltageDrop ) && vIN <= vIN_MAX) ? 1: 0;                   // PANEL DETECTED
OTE =  (PV_ON ==1 ) ? 1: 0;                                                       //OUTPUT ENABLE
LOD_ON = (ACstate == 1 || DCstate ==1) ? 1 : 0;

if(vOUT <= vOUT_MIN) { LOAD = 0; BTL = 1;} else{ LOAD = 1; BTL = 0;}              /////////low battery protection
if((ACstate == 1 || DCstate== 1) && BTL==1) { ACstate = 0; DCstate = 0; PORTD &= ~(1<<DC_OUTPUT); PORTD &= ~(1 << AC_OUTPUT);}
//------------------------------------> Recovery period for morning---------------
if(PV_ON ==1 && pIN <= PWR_IN_THRES){
if(millis()- last_count_time >= count_time){
  last_count_time = millis();
 POWER_ZERO_COUNT++;
}
}
POWER_ZERO_COUNT >= POWER_ZERO_MAX_COUNT ? (REC = 1,  POWER_ZERO_COUNT = 0,PORTB &= ~(1<< BACKFLOW_CONTROL)):(REC = 0);  /// Hahaha

if(OTE ==1 && ERR == 0) {bypassEN = 1; PORTB |= ((1<< BACKFLOW_CONTROL));  } else{ bypassEN = 0; PORTB &= ~(1<< BACKFLOW_CONTROL);}
/* Uncomment to debugg through Serial
Serial.print("IOC=");
Serial.println(IOC);
Serial.print("OOV=");
Serial.println(OOV);
Serial.print("REC=");
Serial.println(REC);
Serial.print("IOV=");
Serial.println(IOV);
Serial.print("LOAD =");
Serial.println(LOAD);
Serial.print("SOT=");
Serial.println(SOT);
Serial.print("fanstatus");
Serial.println(FAN_STATUS);
Serial.print("bypassEN");
Serial.println(bypassEN);
//*/
}

void init_timer(){
    TCCR1A = 0;
    TCCR1B = 0;
    TCNT1 = 0;
            //set timer1 to mode 14(fast PWM, top in ICR1)
    TCCR1B |= ((1 << WGM13)| (1 <<WGM12));
    TCCR1A |= (1<< WGM11);
    TCCR1A |= (1 <<COM1A1); //Clear OCRIA on compare and match, set at bottom
    TCCR1B |= (1<<CS10); // Prescaler 1 for 62.5khz
    ICR1   = icr;   // TOP value at 31.25khz
    OCR1A = DUTYCYCLE* icr ;
}

void PWM(){

    if((vIN) <= 0) { PPWM = 0.00;}
    else{
        PPWM = MPPT_MATH;
        PPWM = constrain(PPWM,min_dutycycle,max_dutycycle);
        delay(10);
    }
     DUTYCYCLE = constrain(DUTYCYCLE, PPWM,max_dutycycle); 
    OCR1A = DUTYCYCLE* icr ;
   MPPT_Enable();
}

void Charging_Algorithm(){
  if(millis()-lastMPPTtime > MPPTUpdate){
    lastMPPTtime = millis();
    if( OTE ==0 || ERR > 0 ) {mppt_Disable();}
    else{ 
        if(REC ==1 ){
            REC = 0;
            mppt_Disable();
            Serial.println("computing the dutycycle=====================");
            Serial.println("");
            Read_Sensors();
             if((vIN) <= 0) { PPWM = 0.00;}
 else{
     PPWM = MPPT_MATH;
     PPWM = constrain(PPWM,min_dutycycle,max_dutycycle);
     delay(10);
 }
 DUTYCYCLE = PPWM;
        }
        else{
     if(cOUT > cOUT_Charge &&   LOD_ON == 0){ DUTYCYCLE -= 0.002;}   
     else if(vOUT > vOUT_MAX){ DUTYCYCLE -= 0.002;}
else{
    if(pIN > PREV_POWER && vIN > PREV_vIN) {DUTYCYCLE -= 0.002;}
   else if(pIN > PREV_POWER && vIN < PREV_vIN) {DUTYCYCLE += 0.002;}
   else if(pIN < PREV_POWER && vIN > PREV_vIN) {DUTYCYCLE += 0.002; }
   else if(pIN < PREV_POWER && vIN < PREV_vIN) {DUTYCYCLE -= 0.002; }
   else if(vOUT < vOUT_MAX) {DUTYCYCLE += 0.002;}
   PREV_POWER = pIN;
   PREV_vIN  = vIN;
}
 PWM();
    } 
    }
 Serial.print("OCR1A================");
 Serial.println(OCR1A);  
} 
}
 void Load_Control(){
if (LOAD ==1){
  int reading2 = (PIND & (1 << DC_BUTTON)) ? 1 : 0;

  // Check if the button state has changed
  if (reading2 != lastbuttonState2) {
    lastDebounce2 = millis();  // Reset the debounce timer
  }

  // If the debounce time has passed, check if the button state is stable
  if ((millis() - lastDebounce2) > debounceDelay) {
    // If the button state has changed, update it
    if (reading2 != buttonState2) {
      buttonState2 = reading2;

      // If the button is pressed, toggle the output state
      if (buttonState2 == 0) {  // LOW means button is pressed (using internal pull-up)
        DCstate = !DCstate;  // Toggle the output state
        
        if (DCstate ==1) {
          PORTD |= (1 << DC_OUTPUT);   //  high
        } else {
          PORTD &= ~(1 << DC_OUTPUT);  //  low
        }
      }
    }
  } 
  lastbuttonState2 = reading2;

  int reading1 = (PIND & (1 << INVERTER_BUTTON)) ? 1 : 0;

  if (reading1 != lastbuttoState1) {
    lastDebounce1 = millis();  
  }

  if ((millis() - lastDebounce1) > debounceDelay) {
    if (reading1 != buttonState1) {
      buttonState1 = reading1;

      if (buttonState1 == 0) {
        ACstate = !ACstate;  
        if (ACstate ==1) {
          PORTD |= (1 << AC_OUTPUT);   //  high
        } else {
          PORTD &= ~(1 << AC_OUTPUT);  //  low
        }
      }
    }
  }
  lastbuttoState1 = reading1;

  }
else{
    if ( ACstate== 1 ||  DCstate == 1) { 
        ACstate = 0;
        DCstate = 0;
    }
}
}


 //----------------------- LCD DISPLAY MONITORING------------------------------------------------------------------------------------//

  void Lcd_Display(){
 if (millis() - lastUpdateTime >= LcdUpdateTime)  {
    if(SOT ==0 && IOC == 0 && OOV == 0){
    if(OTE == 1){
        lcd.clear();
        lcd.setCursor(0,0);
        lcd.write(byte(0));
        lcd.setCursor(1,0);
        lcd.print(vIN);
        lcd.print("V");
        lcd.setCursor(10, 0);
        lcd.write(byte(1));
        lcd.print(vOUT);
        lcd.setCursor(15,0);
        lcd.print("V");
        lcd.setCursor(0,1);
        lcd.print(batteryPercent);
        lcd.print("%");
        lcd.setCursor(9, 1);
        lcd.write(byte(3));
        lcd.setCursor(10,1);
        lcd.print(powerOut, 1);
        lcd.print ("W");
        lcd.setCursor(4, 1);
        lcd.print(cOUT, 1);
        lcd.print("A");
        if (LOD_ON ==1){ 
    lcd.setCursor (8, 0);
 lcd.write(byte(4));   
}

    }
    else{
        lcd.clear();
        lcd.setCursor(0,1);
        lcd.print(batteryPercent);
        lcd.print("%");
        lcd.setCursor(4,1);
         lcd.write(byte(1));
        lcd.setCursor(5, 1);
        lcd.print(vOUT,1);
        lcd.print("V");
        lcd.setCursor(12,1);
        lcd.print(temperature);
        lcd.write(byte(2));
        lcd.print("C");
        if (LOD_ON ==1){ 
            lcd.setCursor (10, 1);
         lcd.write(byte(4));   
        }
        
    }
    }
    else{
        if(IOC == 1) {
            lcd.clear();lcd.setCursor(0, 0); lcd.print("  WARNING"); lcd.setCursor( 0,1); lcd.print(" Over Current");
        }
        if (SOT == 1){
lcd.clear();lcd.setCursor(0, 0); lcd.print("  WARNING"); lcd.setCursor(0, 1); lcd.print(" Over Temperature");
        }
        if (OOV == 1)
        {
           lcd.clear();lcd.setCursor(0, 0); lcd.print("  WARNING");
lcd.setCursor(0, 1); lcd.print(" Over Voltage");
        }
               if (BTL == 1)
       {
          lcd.clear();lcd.setCursor(0, 0); lcd.print("  WARNING");
lcd.setCursor(0, 1); lcd.print(" Over Voltage");
       }       
    }
    lastUpdateTime = millis();
 }
 if (OTE ==0 && (SOT ==0 && IOC == 0 && OOV == 0)){
    if(millis()- lastscroll >= ScrollTime){
        lastscroll = millis();
        int pos = ScrollIndex% message.length();
        String Disp = message.substring(pos) + message.substring(0, pos);
        lcd.setCursor(0,0);
        lcd.print(Disp.substring(0, lcdCol));
        ScrollIndex++;
    }
  }
}

//--------------------------------------------POWER CONTROL AND MONITORING--------------------------------------------------------//
  void sleep(){
 if(OTE == 0){
 if(LOD_ON ==0){
 if (millis()-lAST_PWR_EN_TIME >= IDLE_TIME_LIMIT){
  lAST_PWR_EN_TIME = millis();
  PORTC |= (1<< Buzzer);
  delay(80);
  PORTB &= ~(1<< PWR_EN);
  Serial.println(" POWER DISABLDE================================");
   }
  }
 }
else{ }
  }
  void PWR_CNTRL(){
    bool reading  = !(PINB & ( 1<< PWR_DISABLE));
if(OTE == 0){
    if(reading){
if(buttonPressTime ==0){ buttonPressTime = millis();}
    else if( millis()- buttonPressTime > Power_on_time){
        {PORTB &= ~(1<< PWR_EN); }  
    }
    buttonPressTime =0;
    }
    else { buttonPressTime = 0;}
}
    if(millis() - lastBuzzerTime >= Event_timer) {
        lastBuzzerTime = millis();
        PORTC |= (1<<Buzzer);
        delay(1000);
        PORTC &= ~(1<<Buzzer);
    }
  }
void setup() {
Serial.begin(115200);
pinMode(TempSensor,INPUT);
pinMode(ADC_ALERT,INPUT);
DDRC |= (1<< Buzzer);
DDRB |= (( 1<< PWR_EN) | (1<<PWM_OUT1) | (1<<BUCK_EN) | (1<<BACKFLOW_CONTROL) | (1<<LED_STATUS)); // Set pins as outputs
DDRD |= ((1<<DC_OUTPUT) | (1<< FAN) | (1<< AC_OUTPUT));
DDRD &= ~((1<<INVERTER_BUTTON) | (1<< PWR_DISABLE) | (1<<DC_BUTTON));                          // Set pins as inputs
PORTD |= ((1<<INVERTER_BUTTON) |(1<< DC_BUTTON) |( 1<< PWR_DISABLE));                          // Set the pins with pullup
PORTB |= (1<<PWR_DISABLE);
PORTD &= ~((1<<DC_OUTPUT) | (1<< FAN) | (1<< AC_OUTPUT));                                       // Set the pins low
PORTB &= ~((1<<BACKFLOW_CONTROL)| ( 1<<BUCK_EN));
PORTB |= ((1<<LED_STATUS));
PORTC |= (1 << Buzzer); 

ADC_SetGain();
if(!ads.begin()){ Serial.println("ADS UNSUCCESSFUL");}
else { Serial.println( "ADS OK"); }
init_timer();
lcd.begin(16,2);
lcd.setBacklight(1);
lcd.createChar(0, Sol_char);
lcd.createChar(1, Bat_char);
lcd.createChar(2, Temp_char);
lcd.createChar(3, BOLT);
lcd.createChar(4, LOD);

PORTB |= (1<<PWR_EN);
PORTC &= ~(1 << Buzzer);
}

void loop() {
    Read_Sensors();
    Device_Protection();
    Charging_Algorithm();
    Load_Control();
    Lcd_Display();
    PWR_CNTRL();
    sleep();
}
 